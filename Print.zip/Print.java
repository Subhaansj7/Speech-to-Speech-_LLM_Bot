
import java.util.*;
class Patient{
	int pid;
	String pname;
	String diagnosis;
	int days;
	public Patient(int pid,String pname, String diagnosis,int days) {
		this.pid=pid;
		this.pname=pname;
		this.diagnosis=diagnosis;
		this.days=days;
	}
	public int  getPid() {
		return pid;
		
		
	}
	public String getName() {
		return pname;
		
	}
	public String getDiagnosis() {
		return diagnosis;
		
	}
	public int  getDays() {
		return days;
		
		
	}
	public void displayDetails() {
		System.out.println("Id: "+pid+" Name: "+pname+" Diagnosis: "+diagnosis);
	}
}
class Database {
	ArrayList <Patient> arr = new ArrayList<>();

	
	public void addBook(Patient patient) {
		arr.add(patient);
		System.out.println("Patient Added Sucesfuly");
	}
	public void removeBook(int pid) {
		if(arr.isEmpty()) {
			System.out.println("Database is Empty");
		}
		else {
			for (int i = 0; i < arr.size(); i++) {
				if(arr.get(i).getPid()==(pid)) {
					arr.remove(i);
					System.out.println("Removed Succesfully");
				}
			}
		}
	}
	public void findPatient(String diagnosis) {
		if(arr.isEmpty()) {
			System.out.println("Database is Empty");
		}
		else {
			for (int i = 0; i < arr.size(); i++) {
				if(arr.get(i).getDiagnosis().equalsIgnoreCase(diagnosis)) {
					arr.get(i).displayDetails();
				}
			}
		}
	}
	public void findDays(int days) {
		if(arr.isEmpty()) {
			System.out.println("Database is Empty");
		}
		else {
			for (int i = 0; i < arr.size(); i++) {
				if(arr.get(i).getDays()==(days)) {
					arr.get(i).displayDetails();
				}
			}
		}
	}
	
}
class Print{
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Database database = new Database();
		
		while(true) {
			
			System.out.println("-----PATIENT DATABASE-----");
			System.out.println("1.Add Patient");
			System.out.println("2.Remove Patient");
			System.out.println("3.Find Patien by Diagnosis");
			System.out.println("4.Find patient by days");
			System.out.println("5.Exit");
			
			int choice = sc.nextInt();
			sc.nextLine();
			
			switch(choice) {
			case 1: 
				System.out.println("Enter Pid: ");
				int pid = sc.nextInt();
				sc.nextLine();
				System.out.println("Enter Name: ");
				String pname=sc.nextLine();
				System.out.println("Enter Diagnosis: ");
				String diagnosis=sc.nextLine();
				System.out.println("Enter days: ");
				int days= sc.nextInt();
				sc.nextLine();
				database.addBook(new Patient(pid,pname,diagnosis,days));
				break;
				
			case 2:
				System.out.println("Enter Pid: ");
				pid = sc.nextInt();
				database.removeBook(pid);
				break;
				
			case 3:
				System.out.println("Enter diagnosis: ");
				diagnosis=sc.nextLine();
				database.findPatient(diagnosis);
				break;
				
			case 4:
				System.out.println("Enter Days");
				days=sc.nextInt();
				database.findDays(days);
				break;
				
			case 5:
				System.out.println("Application is closed");
				sc.close();
				System.exit(0);
			default:
				System.out.println("Invalid Choice");
				break;
			}
		}
	}
}